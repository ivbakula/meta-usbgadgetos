#ifndef HOTPLUG_H
#define HOTPLUG_H

#include <stdint.h>

int hotplug_open_socket(const char *path);

uint8_t hotplug_get_action(int sockfd);

#endif
