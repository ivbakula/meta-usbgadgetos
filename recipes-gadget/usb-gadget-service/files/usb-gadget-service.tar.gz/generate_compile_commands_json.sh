#!/bin/sh

make --always-make --dry-run \
| jq -Rn --arg dir "$PWD" '
  [
    inputs
    | select(test("(^|[[:space:]])(gcc|g\\+\\+|cc|c\\+\\+)([[:space:]]|$)"))
    | select(test("(^|[[:space:]])-c([[:space:]]|$)"))
    | {
        directory: $dir,
        command: .,
        file: (
          capture("(?<file>[^[:space:]]+\\.(c|cc|cpp|cxx|C|m|mm))([[:space:]]|$)").file
        )
      }
  ]
' > compile_commands.json
