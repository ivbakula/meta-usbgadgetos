#include "usbeph.h"

#include <endian.h>
#include <fcntl.h>
#include <linux/usb/functionfs.h>
#include <unistd.h>

#include "logger.h"

/******************** Descriptors and Strings *******************************/

struct func_desc
{
    struct usb_interface_descriptor intf;
    struct usb_endpoint_descriptor_no_audio sink;
} __attribute__((packed));

struct desc
{
    struct usb_functionfs_descs_head_v2 header;
    __le32 hs_count;
    struct func_desc hs_descs;
} __attribute__((packed));

struct desc ffs_usb0_descs = {
  .header =
    {
      .magic = FUNCTIONFS_DESCRIPTORS_MAGIC_V2,
      .flags = FUNCTIONFS_HAS_HS_DESC,
      .length = sizeof(ffs_usb0_descs),
    },
  .hs_count = 2,
  .hs_descs =
    {
      .intf =
        {
          .bLength = sizeof(struct usb_interface_descriptor),
          .bDescriptorType = USB_DT_INTERFACE,
          .bInterfaceNumber = 0,
          .bAlternateSetting = 0,
          .bNumEndpoints = 1,
          .bInterfaceClass = USB_CLASS_VENDOR_SPEC,
          .bInterfaceSubClass = 0x01,
          .bInterfaceProtocol = 0x00,
          .iInterface = 0x01,
        },
      .sink =
        {
          .bLength = sizeof(struct usb_endpoint_descriptor_no_audio),
          .bDescriptorType = USB_DT_ENDPOINT,
          .bEndpointAddress = 1 | USB_DIR_IN,
          .bmAttributes = USB_ENDPOINT_XFER_BULK | USB_ENDPOINT_SYNC_ASYNC,
          .wMaxPacketSize = 512,
        },
    },
};

#define STR_INTERFACE "HELLO WORLD"

static const struct
{
    struct usb_functionfs_strings_head header;
    struct
    {
        __le16 code;
        const char str1[sizeof(STR_INTERFACE)];
    } __attribute__((packed)) lang0;
} __attribute__((packed)) strings = {
  .header =
    {
      .magic = FUNCTIONFS_STRINGS_MAGIC,
      .length = sizeof(strings),
      .str_count = 1,
      .lang_count = 1,
    },
  .lang0 =
    {
      0x0409,
      STR_INTERFACE,
    },
};

int usb_configure_dev(const char *path)
{
    int ep0 = open(path, O_RDWR);
    if (ep0 < 0) {
        TRACE(LOG_ERR, "Unable to open ep0");
        return ep0;
    }

    int rc = write(ep0, &ffs_usb0_descs, sizeof(ffs_usb0_descs));
    if (rc < 0) {
        TRACE(LOG_ERR, "Unable to write USB interface descriptor");
        return rc;
    }

    rc = write(ep0, &strings, sizeof(strings));
    if (rc < 0) {
        TRACE(LOG_ERR, "Unable to write USB interface string");
        return rc;
    }

    return ep0;
}

int usb_open_bulkep(const char *path)
{
    int ep1 = open(path, O_WRONLY | O_NONBLOCK);
    if (ep1 < 0) {
        TRACE(LOG_ERR, "Unable to open ep1");
    }
    return ep1;
}

int usb_send_event(int ep, struct gamepad_state *ev)
{
    struct usb_message msg = {
      .flags = ev->flags,
      .connected = ev->connected,
      .throttle_value = htole16(ev->throttle_value),
      .brake_value = htole16(ev->brake_value),
      .steer_value = htole16(ev->steer_value),
    };

    return write(ep, (void *)&msg, sizeof(msg));
}
