#ifndef LOGGER_H
#define LOGGER_H

#include <stdio.h>
#include <syslog.h>

#ifdef SYSLOG
#define TRACE(prio, fmt, ...) syslog(prio, "[%s:%d] " fmt, __FILE__, __LINE__, ##__VA_ARGS__)
#else
static inline const char *lvl_to_str(int lvl)
{
    switch (lvl) {
        case LOG_ERR:
            return "ERROR";
        case LOG_WARNING:
            return "WARNING";
        case LOG_INFO:
            return "INFO";
        case LOG_DEBUG:
            return "DEBUG";
        default:
            return "LOG";
    }
}

#define TRACE(prio, fmt, ...) fprintf(stderr, "[%s] [%s:%d] " fmt "\n", lvl_to_str(prio), __FILE__, __LINE__, ##__VA_ARGS__)
#endif

#endif
