#!/bin/sh

## This script should live in /usr/sbin/hotplug.sh

GADGET_RUN_DIR="/run/gadget"
GADGET_SOCKET="$GADGET_RUN_DIR/gadget.sock"
GAMEPAD_STATE="$1"
DEV_NODE_PATH="$2"
DEV_NODE_SYMLINK="$GADGET_RUN_DIR/event"

if [[ ! -e "$GADGET_SOCKET" ]]; then
    echo "gadget.service *not* running" >> $GADGET_RUN_DIR/hotplug.log
    exit
fi

if [[ "$GAMEPAD_STATE" == "1" ]]; then
    if [[ ! -e "$DEV_NODE_SYMLINK" ]]; then
	echo $DEV_NODE_SYMLINK " -> " $DEV_NODE_PATH  >> $GADGET_RUN_DIR/hotplug.log
	ln -sf $DEV_NODE_PATH $DEV_NODE_SYMLINK
	echo "1" | socat - UNIX-SENDTO:$GADGET_SOCKET
    else
	echo $DEV_NODE_SYMLINK " Device already connected! Only one gamepad may be connected at time! " >> $GADGET_RUN_DIR/hotplug.log
    fi
elif [[ "$GAMEPAD_STATE" == "0" ]]; then
    if [[ -L "$DEV_NODE_SYMLINK" ]]; then
	echo "0" | socat - UNIX-SENDTO:$GADGET_SOCKET
	echo $DEV_NODE_SYMLINK " -/- " $DEV_NODE_PATH >> $GADGET_RUN_DIR/hotplug.log
	unlink $DEV_NODE_SYMLINK
    fi
else
    echo "Unknown option received: " $GAMEPAD_STATE >> $GADGET_RUN_DIR/hotplug.log
fi
