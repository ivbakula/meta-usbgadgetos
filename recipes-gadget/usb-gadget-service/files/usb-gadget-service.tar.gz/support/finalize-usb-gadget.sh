#!/bin/sh

#
# /usr/bin/finalize-usb-gadget.sh
#
# Enables USB gadget UDC. This shall be done after the gadget is completely
# setup.
# 1. USB Device and configuration nodes are configured (via configfs -> initialize-gadget.sh script
#    executed successfully)
#
# 2. USB Interface and Endpoint descriptors are successfuly configured -> done by gadget.service via
#    FunctionFS
# 
GADGET_CFG_ROOT=/sys/kernel/config/usb_gadget/g1

UDC="$(ls /sys/class/udc | head -n 1)"
echo "$UDC" > "$GADGET_CFG_ROOT/UDC"

# Retrigger UDEV events received/produced during enumeration phase
# (before we were up and running). So that we know if there was gamepad attached
# during the startup or even before.
udevadm trigger --action=add --wait-daemon --settle
