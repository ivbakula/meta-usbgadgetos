#include <errno.h>
#include <poll.h>
#include <sys/syslog.h>
#include <sys/timerfd.h>
#include <systemd/sd-daemon.h>
#include <time.h>
#include <unistd.h>

#include "common.h"
#include "gamepad.h"
#include "hotplug.h"
#include "logger.h"
#include "usbeph.h"

#define TIMER_PERIOD_NS 16666666  // 60 Hz
#define HOTPLUG_FD      0
#define TIMER_FD        1
#define EVDEV_FD        2

#define POLL_TO(x) (x + 1)

static const struct itimerspec ts = {
  .it_value =
    {
      .tv_sec = 0,
      .tv_nsec = TIMER_PERIOD_NS,
    },
  .it_interval =
    {
      .tv_sec = 0,
      .tv_nsec = TIMER_PERIOD_NS,
    },
};

int main()
{
#ifdef SYSLOG
    openlog("gadget", LOG_PID, LOG_USER);
#endif
    /************************* HOTPLUG AND ENUMERATION STUFF ***********************/
    int sockfd = hotplug_open_socket(HOTPLUG_SOCKET_PATH);
    if (sockfd < 0) {
        TRACE(LOG_ERR, "Unable to open hotplug socket! Errno: %d", sockfd);
        return sockfd;
    }
    TRACE(LOG_INFO, "Hotplug socket successfuly opened!");

    /************************ USB DEVICE CONFIGURATION *****************************/
    int ep0 = usb_configure_dev(INIT_ENDPOINT_PATH);
    if (ep0 < 0) {
        TRACE(LOG_ERR, "Unable to configure USB devce! Errno: %d", ep0);
        return ep0;
    }
    TRACE(LOG_INFO, "USB device successfully configured!");

    int bulk_ep = usb_open_bulkep(DATA_ENDPOINT_PATH);
    if (bulk_ep < 0) {
        TRACE(LOG_ERR, "Unable to open bulk endpoint! Errno: %d", bulk_ep);
        return bulk_ep;
    }
    TRACE(LOG_INFO, "USB bulk endpoint successfuly opened!");

    /*************************** LIBEVDEV STUFF ***********************************/
    struct libevdev *dev = NULL;
    int gpadfd = -1;

    /*************************** TIMER STUFF ***************************************/
    int timer_fd = timerfd_create(CLOCK_MONOTONIC, 0);
    if (timer_fd < 0) {
        TRACE(LOG_ERR, "Unable to create timer! Errno: %d", timer_fd);
        return timer_fd;
    }
    int rc = timerfd_settime(timer_fd, 0, &ts, NULL);
    if (rc < 0) {
        TRACE(LOG_ERR, "Unable to arm the timer! Errno: %d", rc);
        return rc;
    }

    TRACE(LOG_INFO, "Timer successfuly created!");

    /*******************  NOTIFY SYSTEMD THAT WE'RE READY *************************/
    TRACE(LOG_INFO, "Notify systemd!");
    sd_notify(0, "READY=1");

    /**************************** POLLING STUFF ***********************************/
    struct pollfd pfd[] = {
      [HOTPLUG_FD] =
        {
          .fd = sockfd,
          .events = POLLIN,
        },
      [TIMER_FD] =
        {
          .fd = timer_fd,
          .events = POLLIN,
        },
      [EVDEV_FD] =
        {
          .fd = gpadfd,
          .events = POLLIN,
        },
    };

    /**************************** MAIN EVENT LOOP  ***********************************/

    // Poll everything except evdev, as it's not yet connected, at least we don't know
    // about it until udev is retriggered ;)
    int no_poll = POLL_TO(TIMER_FD);
    struct gamepad_state curr_status = {.connected = false, .throttle_value = 0, .brake_value = 0, .steer_value = 2047};

    for (;;) {
        poll(pfd, no_poll, -1);
        if (pfd[HOTPLUG_FD].revents & POLLIN) {
            uint8_t st = hotplug_get_action(sockfd);
            switch (st) {
                case EVENT_CONNECT:
                    gpadfd = gamepad_open_device(EVDEV_FILE, &dev);
                    if (gpadfd > 0 && dev != NULL) {
                        pfd[EVDEV_FD].fd = gpadfd;
                        no_poll = POLL_TO(EVDEV_FD);
                        TRACE(LOG_INFO, "Gamepad connected!");
                        curr_status.connected = true;
                    } else {
                        TRACE(LOG_ERR, "Failed to open gamepad: %d", gpadfd);
                        pfd[EVDEV_FD].fd = -1;
                        dev = NULL;
                    }

                    break;

                case EVENT_DISCONNECT:
                    gamepad_close_device(gpadfd, &dev);
                    gpadfd = pfd[EVDEV_FD].fd = -1;
                    no_poll = POLL_TO(TIMER_FD);
                    TRACE(LOG_INFO, "Gamepad disconnected!");
                    curr_status.connected = false;
                    break;

                default:
                    TRACE(LOG_ERR, "Unknown event received from hotplug!");
            }
        }

        if (gpadfd > 0 && (pfd[EVDEV_FD].revents & POLLIN)) {
            gamepad_read_event(dev, &curr_status);
            TRACE(LOG_DEBUG, "Received: flags: %d, throttle: %d, brake: %d, steer: %d", curr_status.flags,
              curr_status.throttle_value, curr_status.brake_value, curr_status.steer_value);
        }

        if ((pfd[TIMER_FD].revents & POLLIN)) {
            uint64_t exp;
            read(timer_fd, &exp, sizeof(exp));
            usb_send_event(bulk_ep, &curr_status);
        }
    }

    return 0;
}
