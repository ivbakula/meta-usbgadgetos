#include "gamepad.h"

#include <errno.h>
#include <fcntl.h>
#include <unistd.h>

#include "common.h"
#include "logger.h"

static const struct input_absinfo *ev_data_range[] = {
  [EVENT_THROTTLE_INDEX] = NULL,
  [EVENT_BRAKE_INDEX] = NULL,
  [EVENT_STEER_INDEX] = NULL,
};

int gamepad_open_device(const char *path, struct libevdev **dev)
{
    if (!dev) {
        TRACE(LOG_ERR, "Error referencing libevdev device! Object is NULL");
        return -1;
    }

    int fd = open(path, O_RDONLY | O_NONBLOCK);
    if (fd < 0) {
        TRACE(LOG_ERR, "Error opening evdev file %s! Error: %d", path, fd);
        return -1;
    }

    int rc = libevdev_new_from_fd(fd, dev);
    if (rc < 0) {
        TRACE(LOG_ERR, "Failed to initialize libevdev: %d", -rc);
        close(fd);
        return -1;
    }

    TRACE(LOG_INFO, "Calibrating device...");
    ev_data_range[EVENT_THROTTLE_INDEX] = libevdev_get_abs_info(*dev, ABS_RZ);
    ev_data_range[EVENT_BRAKE_INDEX] = libevdev_get_abs_info(*dev, ABS_Z);
    ev_data_range[EVENT_STEER_INDEX] = libevdev_get_abs_info(*dev, ABS_X);
    TRACE(LOG_INFO, "Device calibrated");

    return fd;
}

static uint16_t scale(int16_t x, int16_t min, int16_t max)
{
    /*
     * Scaling formula:
     *
     *            4095 * (x - min)
     * v = x' = -------------------
     *              max - min
     */
    int32_t n = 4095 * (x - min);
    int32_t d = max - min;
    int32_t v = n / d;

    // Check if we're dealing with 16 bit unassigned integer.
    if ((v > 4095) || (v < 0)) {
        TRACE(LOG_ERR, "Scaling failed! Expected 16 bit integer, got 0x%04x", v);
        return 0xffff;
    }

    return v;
}

static void gamepad_map_abs_event(const struct input_event *ev, struct gamepad_state *ret)
{
    if (ev->type != EV_ABS)
        return;

    switch (ev->code) {
        case ABS_X:
            ret->flags |= EVENT_STEER;
            ret->steer_value =
              scale(ev->value, ev_data_range[EVENT_STEER_INDEX]->minimum, ev_data_range[EVENT_STEER_INDEX]->maximum);
            break;

        case ABS_Z:
            ret->flags |= EVENT_BRAKE;
            ret->brake_value =
              scale(ev->value, ev_data_range[EVENT_BRAKE_INDEX]->minimum, ev_data_range[EVENT_BRAKE_INDEX]->maximum);
            break;

        case ABS_RZ:
            ret->flags |= EVENT_THROTTLE;
            ret->throttle_value =
              scale(ev->value, ev_data_range[EVENT_THROTTLE_INDEX]->minimum, ev_data_range[EVENT_THROTTLE_INDEX]->maximum);
            break;

        case ABS_Y:
            /* We don't care about Y axis. */
        default:
            break;
    }
}

void gamepad_read_event(struct libevdev *dev, struct gamepad_state *st)
{
    struct input_event ev;

    for (;;) {
        int rc = libevdev_next_event(dev, LIBEVDEV_READ_FLAG_NORMAL, &ev);

        switch (rc) {
            case LIBEVDEV_READ_STATUS_SUCCESS:
                gamepad_map_abs_event(&ev, st);
                break;

            case LIBEVDEV_READ_STATUS_SYNC:
                TRACE(LOG_ERR, "Events dropped, resyncing...");
                while (libevdev_next_event(dev, LIBEVDEV_READ_FLAG_SYNC, &ev) == LIBEVDEV_READ_STATUS_SYNC)
                    ;
                /* As we're out of sync return SYNC_LOST event */
                st->flags |= EVENT_SYNC_LOST;
                continue;

            case -EAGAIN:
                return;

            case -ENODEV:
                TRACE(LOG_DEBUG, "Gamepad disconnected, I don't know what to do...");
                st->connected = false;
                st->flags |= EVENT_DISCONNECT;
                return;

            default:
                if (rc < 0) {
                    TRACE(LOG_ERR, "libevdev_next_event failed: %d", rc);
                    st->flags |= EVENT_INVALID;
                    return;
                }
                break;
        }

        // End of evdev poll of events is signalized via EV_SYN, so we're done here
        if (ev.type == EV_SYN)
            return;
    }
}

int gamepad_close_device(int evdev_fd, struct libevdev **dev)
{
    if (!dev) {
        TRACE(LOG_ERR, "Invalid libevdev device! Null pointer passed");
        return -1;
    }

    libevdev_free(*dev);
    close(evdev_fd);
    *dev = NULL;
    return 0;
}
