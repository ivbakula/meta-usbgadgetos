#ifndef COMMON_H
#define COMMON_H

#include <stdbool.h>
#include <stdint.h>

#define HOTPLUG_SOCKET_PATH "/run/gadget/gadget.sock"
#define EVDEV_FILE          "/run/gadget/event"
#define INIT_ENDPOINT_PATH  "/dev/ffs-usb0/ep0"
#define DATA_ENDPOINT_PATH  "/dev/ffs-usb0/ep1"

#define EVENT_THROTTLE_INDEX   0x0
#define EVENT_BRAKE_INDEX      0x1
#define EVENT_STEER_INDEX      0x2
#define EVENT_CONNECT_INDEX    0x3
#define EVENT_DISCONNECT_INDEX 0x4
#define EVENT_SYNC_LOST_INDEX  0x5
#define EVENT_INVALID_INDEX    0x6

#define EVENT_NOP        0x0
#define EVENT_THROTTLE   (1 << EVENT_THROTTLE_INDEX)
#define EVENT_BRAKE      (1 << EVENT_BRAKE_INDEX)
#define EVENT_STEER      (1 << EVENT_STEER_INDEX)
#define EVENT_CONNECT    (1 << EVENT_CONNECT_INDEX)
#define EVENT_DISCONNECT (1 << EVENT_DISCONNECT_INDEX)
#define EVENT_SYNC_LOST  (1 << EVENT_SYNC_LOST_INDEX)
#define EVENT_INVALID    (1 << EVENT_INVALID_INDEX)

#define EVENT_CAR_CONTROL_MASK (EVENT_THROTTLE | EVENT_BRAKE | EVENT_STEER)
#define EVENT_PLUG_MASK        (EVENT_CONNECT | EVENT_DISCONNECT)

/* It would be good to share this one between USB Gadget and Host, but I don't mind it this way.
 * It's not production code is something I tell myself at nights.
 */
struct usb_message
{
    bool connected;
    uint8_t flags;
    uint16_t throttle_value;
    uint16_t brake_value;
    uint16_t steer_value;
} __attribute__((packed));

/* Bit silly, having two structs, maybe I should use only one :D */
struct gamepad_state
{
    bool connected;
    uint8_t flags;
    int16_t throttle_value;
    int16_t brake_value;
    int16_t steer_value;
};

#endif
