#ifndef EVDEV_H
#define EVDEV_H

#include <libevdev/libevdev.h>

#include "common.h"

int gamepad_open_device(const char *path, struct libevdev **dev);

void gamepad_read_event(struct libevdev *dev, struct gamepad_state *st);

int gamepad_close_device(int evdev_fd, struct libevdev **dev);

#endif
