#include <endian.h>
#include <errno.h>
#include <fcntl.h>
#include <libevdev-1.0/libevdev/libevdev.h>
#include <linux/usb/functionfs.h>
#include <poll.h>
#include <stdint.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/timerfd.h>
#include <sys/un.h>
#include <syslog.h>
#include <systemd/sd-daemon.h>
#include <unistd.h>

#include "logger.h"

typedef enum
{
    State_Init,
    State_Main,
    State_Wait,
} State_e;

int timer_arm(long period_ns)
{
    int fd = timerfd_create(CLOCK_MONOTONIC, 0);
    if (fd < 0) {
        TRACE(LOG_ERR, "Timer creation error!");
        return fd;
    }

    struct itimerspec ts = {
      .it_value =
        {
          .tv_sec = 0,
          .tv_nsec = period_ns,
        },
      .it_interval =
        {
          .tv_sec = 0,
          .tv_nsec = period_ns,
        },
    };

    int rc = timerfd_settime(fd, 0, &ts, NULL);
    if (rc < 0) {
        TRACE(LOG_ERR, "Unable to initialize timer!");
        close(fd);
        return -1;
    }
    return fd;
}

State_e handle_state_init()
{
    TRACE(LOG_INFO, "Notify systemd");
    sd_notify(0, "READY=1");
    // TODO: Notify systemd that we're up and running, and we're waiting for UDEV to send us hotplug event
    // TODO: Notify systemd that USB device is setup. So other scripts need to start USB.
    return State_Wait;
}

State_e handle_state_wait(int sockfd, int ep)
{
    struct pollfd pfd[1] = {
      {
        .fd = sockfd,
        .events = POLLIN,
      },
    };

    for (;;) {
        poll(pfd, 1, -1);
        if ((pfd[0].revents & POLLIN)) {
            Action_e action = get_device_action(sockfd);
            if (action == Action_Connect) {
                TRACE(LOG_INFO, "Gamepad connected!");
                GamepadEvent_t ev = {.code = NOTIFY_CONNECT, .value = 0};
                write_ep(ep, ev);
                return State_Main;
            }
        }
    }
}

State_e handle_state_main(int sockfd, int ep)
{
    struct libevdev *dev;
    int evdevfd = libevdev_open_device(EVDEV_FILE, &dev);
    int timerfd = timer_arm(16666666);

    struct pollfd pfd[4] = {
      {
        .fd = sockfd,
        .events = POLLIN,
      },
      {
        .fd = evdevfd,
        .events = POLLIN,
      },
      {
        .fd = timerfd,
        .events = POLLIN,
      },
    };

    for (;;) {
        GamepadEvent_t ev = {.code = NOP, .value = 0};
        poll(pfd, 3, -1);
        if (pfd[0].revents & POLLIN) {
            Action_e action = get_device_action(sockfd);
            if (action == Action_Disconnect) {
                TRACE(LOG_INFO, "Gamepad disconnected!");
                ev.code = NOTIFY_DISCONNECT;
                ev.value = 0;
                write_ep(ep, ev);
                libevdev_close_device(evdevfd, &dev);
                close(timerfd);
                return State_Wait;
            }
        }

        if (pfd[1].revents & POLLIN) {
            ev = libevdev_read_event(dev);
        }

        if ((pfd[2].revents & POLLIN)) {
            write_ep(ep, ev);

            if (ev.code != NOP)
                TRACE(LOG_DEBUG, "Received event: %s : %d", evcode_spelling[ev.code], ev.value);
        }
    }
    return State_Wait;
}

int main(int argc, const char *argv[])
{
    State_e st = State_Init;
    for (;;) {
        switch (st) {
            case State_Init:
                st = handle_state_init();
                break;

            case State_Wait:
                st = handle_state_wait(sockfd, ep1);
                break;

            case State_Main:
                st = handle_state_main(sockfd, ep1);
                break;
            default:
                break;
        }
    }
}
