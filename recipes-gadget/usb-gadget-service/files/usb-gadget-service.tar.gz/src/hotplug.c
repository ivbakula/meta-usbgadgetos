#include "hotplug.h"

#include <fcntl.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>

#include "common.h"
#include "logger.h"

int hotplug_open_socket(const char *path)
{
    int sockfd = socket(AF_UNIX, SOCK_DGRAM, 0);

    if (sockfd < 0) {
        TRACE(LOG_ERR, "Error opening socket! %s", strerror(sockfd));
        return sockfd;
    }

    fcntl(sockfd, F_SETFL, O_NONBLOCK);
    struct sockaddr_un addr;
    memset(&addr, 0, sizeof(addr));
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, path, sizeof(addr.sun_path) - 1);

    // Just to make sure that there is no junk over there
    unlink(path);

    int rc = bind(sockfd, (struct sockaddr *)&addr, sizeof(addr));
    if (rc < 0) {
        TRACE(LOG_ERR, "Bind to socket failed! %s", strerror(rc));
        return rc;
    }

    return sockfd;
}

uint8_t hotplug_get_action(int sockfd)
{
    char buff[4] = {};
    int len = recv(sockfd, (void *)&buff, 4, 0);
    if (len < 0) {
        TRACE(LOG_ERR, "Error reading socket: %d", len);
        return EVENT_INVALID;
    }

    TRACE(LOG_DEBUG, "Received %d bytes: %s", len, buff);
    // switch LoL
    switch (buff[0]) {
        case '0':
            return EVENT_DISCONNECT;
        case '1':
            return EVENT_CONNECT;
    }
    return EVENT_INVALID;
}
