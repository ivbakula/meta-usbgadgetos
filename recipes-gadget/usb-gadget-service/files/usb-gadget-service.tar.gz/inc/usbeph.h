#ifndef USBEPH_H
#define USBEPH_H

#include "common.h"

/**
 * @brief configures interface and endpoint with default descriptor values.
 *
 * @param path path to FFS configuration endpoint
 *
 * @return file descriptor of FFS configuration endpoint. This file descriptor needs to be opened
 *         as long as we want to continue using the device. When descriptor is closed, device and it's
 *         configuration is considered as non working. Sorry for bad description. It's really late right now.
 */
int usb_configure_dev(const char *path);

/**
 * @brief opens bulk endpoint provided by FFS. The endpoint is opened in WRONLY and NONBLOCK mode. This function
 *        depends on usb_configure_dev function.
 *
 * @param path pat to FFS bulk endpoint
 *
 * @return file descriptor of bulk endpoint
 */
int usb_open_bulkep(const char *path);

/**
 * @brief Sends gamepad_event received over USB. This function makes sure endiannes is correct.
 *
 * @param ep: USB FFS bulk endpoint file descriptor
 *
 * @param ev: Gamepad event we wish to send
 *
 */
int usb_send_event(int ep, struct gamepad_state *st);

#endif
